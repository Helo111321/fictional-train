#include <REGX52.H>
#include "AT24C02.h"
#include "Buzzer.h"
#include "Delay.h"
#include "DS18B20.h"
#include "Key.h"
#include "LCD1602.h"
#include "Timer0.h"

sbit Motor = P1^0;

unsigned char Compare = 0, Counter = 0;
unsigned char KeyNum = 0;
unsigned char Speed = 0;
unsigned char X = 0;
float T = 0.0, TShow = 0.0;
char TH = 20; 

#define SPEED_0 0
#define SPEED_1 1
#define SPEED_2 2
#define SPEED_3 3

void updateTemperatureDisplay(void) {
    if (T < 0) {
        LCD_ShowChar(1, 3, '-');
        TShow = -T;
    } else {
        LCD_ShowChar(1, 3, '+');
        TShow = T;
    }
    LCD_ShowNum(1, 4, (unsigned int)TShow, 3);
    LCD_ShowChar(1, 7, '.');
    LCD_ShowNum(1, 8, (unsigned int)(TShow * 10000) % 10000, 4);
}

void processKeyInput(void) {
    switch (KeyNum) {
        case 1:
            if (TH < 125) TH++;
            break;
        case 2: 
            if (TH > 0) TH--;
            break;
        case 3: 
            X = !X;
            break;
        case 4: 
            Speed = (Speed + 1) % 4;
            Compare = (Speed == SPEED_1) ? 50 : 
                     (Speed == SPEED_2) ? 75 : 
                     (Speed == SPEED_3) ? 100 : 0;
            LCD_ShowNum(2, 12, Speed, 1);
            break;
    }
    if (KeyNum) {
        LCD_ShowSignedNum(2, 4, TH, 3);
        AT24C02_WriteByte(0, TH);
        Delay(5);
    }
}

void updateMotorControl(void) {
    if (X == 0) {
        Compare = (T > TH) ? 100 : 0;
        if (T > TH) Buzzer_Time(100);
    }
}

void main() {
    DS18B20_ConverT();
    TH = DS18B20_ReadT();
    
    if (TH > 125 || TH < 0) TH = 20;
    
    DS18B20_ConverT();
    Delay(1000);
    
    LCD_Init();
    LCD_ShowString(1, 1, "T:   .    ");
    LCD_ShowString(2, 1, "TH:      X:");
    LCD_ShowSignedNum(2, 4, TH, 3);
    LCD_ShowNum(2, 12, Speed, 1);
    
    Timer0_Init();
    
    while (1) {
        KeyNum = Key_NumBer();
        DS18B20_ConverT();
        T = DS18B20_ReadT();
        
        updateTemperatureDisplay();  
        processKeyInput();         
        updateMotorControl();       
    }
}

void Timer0_Routine() interrupt 1 {
    static unsigned int T0Count = 0;
  
    TL0 = 0x9C;     
    TH0 = 0xFF;     
    
  
    if (++T0Count >= 100) {
        T0Count = 0;
        Key_Loop();
    }

    Motor = (++Counter % 100 < Compare) ? 1 : 0;
}