#ifndef __KEY_H__
#define __KEY_H__

unsigned char Key_NumBer(void);

unsigned char Key_Loop(void);

#endif