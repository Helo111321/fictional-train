#include <REGX52.H>
#include <INTRINS.H>

sbit Buzzer=P2^5;	//蜂鸣器端口：

/**
  *	@brief	蜂鸣器私有延时函数，延时500us
  *	@param	无
  *	@retval	无
  */
void Buzzer_Delay500us()		
{
	unsigned char i;

	_nop_();
	i = 247;
	while (--i);
}

/**
  *	@brief	蜂鸣器发声
  *	@param	ms	发声的时长
  *	@retval	无
  */
void Buzzer_Time(unsigned int ms)	//模块主函数（带定义变量）
{
	unsigned int i;
	for(i=0;i<ms*2;i++)	//响多少秒
	{
	Buzzer=!Buzzer;
	Buzzer_Delay500us();	//响的频率引用函数
	}
}
