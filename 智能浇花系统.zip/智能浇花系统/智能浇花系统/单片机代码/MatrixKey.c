#include <REGX52.H>
#include "Delay.h"

unsigned char MatrixKey_KeyNumber;

unsigned char MatrixKey_NumBer(void)
{
	unsigned char Temp;
	Temp=MatrixKey_KeyNumber;
	MatrixKey_KeyNumber=0;
	return Temp;
}


unsigned char MatrixKey()
{
	unsigned char KeyNumber=0;
	
	P1=0xFF;
	P1_3=0;
	if(P1_7==0){KeyNumber=1;}
	if(P1_6==0){KeyNumber=5;}
	if(P1_5==0){KeyNumber=9;}
	if(P1_4==0){KeyNumber=13;}
	
	P1=0xFF;
	P1_2=0;
	if(P1_7==0){KeyNumber=2;}
	if(P1_6==0){KeyNumber=6;}
	if(P1_5==0){KeyNumber=10;}
	if(P1_4==0){KeyNumber=14;}
	
	P1=0xFF;
	P1_1=0;
	if(P1_7==0){KeyNumber=3;}
	if(P1_6==0){KeyNumber=7;}
	if(P1_5==0){KeyNumber=11;}
	if(P1_4==0){KeyNumber=15;}
	
	P1=0xFF;
	P1_0=0;
	if(P1_7==0){KeyNumber=4;}
	if(P1_6==0){KeyNumber=8;}
	if(P1_5==0){KeyNumber=12;}
	if(P1_4==0){KeyNumber=16;}
	
	return KeyNumber;
}

void MatrixKey_Loop(void)  //定时器驱动函数，它会被定时器控制，进而定时扫描按键
{
	static unsigned char NowState,LastState;
	LastState=NowState;  
	NowState=MatrixKey();
	if(LastState==1 && NowState==0)
	{
		MatrixKey_KeyNumber=1;
	}
	if(LastState==2 && NowState==0)
	{
		MatrixKey_KeyNumber=2;
	}
	if(LastState==3 && NowState==0)
	{
		MatrixKey_KeyNumber=3;
	}
	if(LastState==4 && NowState==0)
	{
		MatrixKey_KeyNumber=4;
	}	
	if(LastState==5 && NowState==0)
	{
		MatrixKey_KeyNumber=5;
	}
	if(LastState==6 && NowState==0)
	{
		MatrixKey_KeyNumber=6;
	}
	if(LastState==7 && NowState==0)
	{
		MatrixKey_KeyNumber=7;
	}
	if(LastState==8 && NowState==0)
	{
		MatrixKey_KeyNumber=8;
	}	
	if(LastState==9 && NowState==0)
	{
		MatrixKey_KeyNumber=9;
	}
	if(LastState==10 && NowState==0)
	{
		MatrixKey_KeyNumber=10;
	}
	if(LastState==11 && NowState==0)
	{
		MatrixKey_KeyNumber=11;
	}
	if(LastState==12 && NowState==0)
	{
		MatrixKey_KeyNumber=12;
	}
	if(LastState==13 && NowState==0)
	{
		MatrixKey_KeyNumber=13;
	}
	if(LastState==14 && NowState==0)
	{
		MatrixKey_KeyNumber=14;
	}
	if(LastState==15 && NowState==0)
	{
		MatrixKey_KeyNumber=15;
	}
	if(LastState==16 && NowState==0)
	{
		MatrixKey_KeyNumber=16;
	}	
	}	


