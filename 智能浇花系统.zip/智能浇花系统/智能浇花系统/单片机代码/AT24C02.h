#ifndef __AT24C02_H_
#define	__AT24C02_H_

AT24C02_WriteByte(unsigned char WordAddress,Data);
AT24C02_ReadByte(unsigned char WordAddress);
#endif